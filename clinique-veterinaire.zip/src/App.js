import { useState } from 'react';

function App() {
  const [form, setForm] = useState({ nom: '', email: '', message: '' });

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    alert('Votre message a été envoyé. Merci !');
  };

  return (
    <div className="p-6 space-y-10 font-sans">
      <section className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Clinique Vétérinaire Universitaire de Lubumbashi</h1>
        <p className="text-lg">Soins vétérinaires, enseignement et recherche au service de la communauté.</p>
      </section>

      <section className="grid gap-4">
        <h2 className="text-2xl font-semibold">À propos</h2>
        <p>Notre clinique universitaire offre des services vétérinaires de qualité tout en formant les futurs vétérinaires et en menant des recherches de pointe.</p>
      </section>

      <section className="grid gap-4">
        <h2 className="text-2xl font-semibold">Nos Services</h2>
        <ul className="list-disc list-inside">
          <li>Consultations générales et spécialisées</li>
          <li>Vaccination et déparasitage</li>
          <li>Chirurgie vétérinaire</li>
          <li>Analyses de laboratoire</li>
          <li>Urgences 24/7</li>
        </ul>
      </section>

      <section className="grid gap-4">
        <h2 className="text-2xl font-semibold">Notre Équipe</h2>
        <p>Une équipe de vétérinaires expérimentés, d’enseignants-chercheurs et d’étudiants en médecine vétérinaire.</p>
      </section>

      <section className="grid gap-4">
        <h2 className="text-2xl font-semibold">Prendre rendez-vous</h2>
        <form className="grid gap-4 max-w-md" onSubmit={handleSubmit}>
          <input name="nom" placeholder="Votre nom" onChange={handleChange} required className="border p-2 rounded" />
          <input name="email" type="email" placeholder="Votre email" onChange={handleChange} required className="border p-2 rounded" />
          <textarea name="message" placeholder="Message ou motif du rendez-vous" onChange={handleChange} required className="border p-2 rounded" />
          <button type="submit" className="bg-blue-600 text-white p-2 rounded">Envoyer</button>
        </form>
      </section>

      <section className="grid gap-4">
        <h2 className="text-2xl font-semibold">Contact</h2>
        <p>Email : contact@cliniquelubumbashi.cd</p>
        <p>Téléphone : +243 999 000 000</p>
      </section>
    </div>
  );
}

export default App;